-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2026 at 11:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ajouhaar_butchery`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `contact_number` varchar(15) NOT NULL DEFAULT 'N/A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `name`, `contact_number`) VALUES
(1, 'Walk-in Customer', 'N/A'),
(2, 'A. Khan', '0821112345'),
(3, 'M. Jacobs', '0735558901'),
(4, 'Tazkeen Vella', '0676921334'),
(5, 'Edin Shand', '0720944916'),
(6, 'Jared Williams', '0728947761'),
(7, 'Mrs R.Hartel', '0725579350'),
(8, 'Mrs H.Jacobs', '0723678821'),
(9, 'Mr M.Jacobs', '0723367811');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(80) NOT NULL,
  `category` varchar(40) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `quantity_on_hand` decimal(10,1) NOT NULL DEFAULT 0.0,
  `reorder_level` decimal(10,1) NOT NULL DEFAULT 0.0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_updated` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `category`, `unit_price`, `quantity_on_hand`, `reorder_level`, `is_active`, `last_updated`) VALUES
(101, 'Beef Mince', 'Beef', 89.99, 0.0, 10.0, 0, '2026-05-13'),
(102, 'Lamb Chops', 'Lamb', 159.99, 8.0, 8.0, 1, '2026-05-13'),
(103, 'Chicken Fillet', 'Poultry', 74.99, 39.5, 12.0, 1, '2026-05-13'),
(104, 'Chicken Wings', 'Poultry', 69.99, 80.0, 20.0, 1, '2026-05-13');

-- --------------------------------------------------------

--
-- Table structure for table `receipts`
--

CREATE TABLE `receipts` (
  `receipt_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `receipt_number` varchar(20) NOT NULL,
  `printed_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `receipts`
--

INSERT INTO `receipts` (`receipt_id`, `sale_id`, `receipt_number`, `printed_date`) VALUES
(1, 301, 'REC-000301', '2026-05-09 09:15:00'),
(2, 302, 'REC-000302', '2026-05-09 10:05:00'),
(3, 303, 'REC-000303', '2026-05-09 12:20:00'),
(4, 304, 'REC-000304', '2026-05-13 21:35:41'),
(5, 305, 'REC-000305', '2026-05-13 21:36:07'),
(6, 306, 'REC-000306', '2026-05-13 22:22:31'),
(7, 307, 'REC-000307', '2026-05-13 22:28:50'),
(8, 308, 'REC-000308', '2026-05-13 22:41:17'),
(9, 309, 'REC-000309', '2026-05-13 22:45:00'),
(10, 310, 'REC-000310', '2026-05-13 23:22:25');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sale_id` int(11) NOT NULL,
  `receipt_number` varchar(20) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sale_date` datetime NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sale_id`, `receipt_number`, `customer_id`, `user_id`, `sale_date`, `total_amount`, `payment_method`) VALUES
(301, 'REC-000301', 1, 2, '2026-05-09 09:15:00', 269.97, 'Cash'),
(302, 'REC-000302', 2, 2, '2026-05-09 10:05:00', 319.98, 'Card'),
(303, 'REC-000303', 3, 3, '2026-05-09 12:20:00', 149.98, 'Cash'),
(304, 'REC-000304', 4, 2, '2026-05-13 21:35:41', 899.90, 'Cash'),
(305, 'REC-000305', 5, 2, '2026-05-13 21:36:07', 3194.65, 'Cash'),
(306, 'REC-000306', 6, 2, '2026-05-13 22:22:31', 299.96, 'Card'),
(307, 'REC-000307', 7, 2, '2026-05-13 22:28:50', 262.47, 'Card'),
(308, 'REC-000308', 8, 3, '2026-05-13 22:41:17', 1599.90, 'Cash'),
(309, 'REC-000309', 9, 3, '2026-05-13 22:45:00', 374.95, 'Card'),
(310, 'REC-000310', 5, 2, '2026-05-13 23:22:25', 699.90, 'Card');

-- --------------------------------------------------------

--
-- Table structure for table `sale_items`
--

CREATE TABLE `sale_items` (
  `sale_item_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity_sold` decimal(10,1) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `line_total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sale_items`
--

INSERT INTO `sale_items` (`sale_item_id`, `sale_id`, `product_id`, `quantity_sold`, `unit_price`, `line_total`) VALUES
(1, 301, 101, 3.0, 89.99, 269.97),
(2, 302, 102, 2.0, 159.99, 319.98),
(3, 303, 103, 2.0, 74.99, 149.98),
(4, 304, 101, 10.0, 89.99, 899.90),
(5, 305, 101, 35.5, 89.99, 3194.65),
(6, 306, 103, 4.0, 74.99, 299.96),
(7, 307, 103, 3.5, 74.99, 262.47),
(8, 308, 102, 10.0, 159.99, 1599.90),
(9, 309, 103, 5.0, 74.99, 374.95),
(10, 310, 104, 10.0, 69.99, 699.90);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(60) NOT NULL,
  `role` varchar(20) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `role`, `username`, `password_hash`, `created_at`) VALUES
(1, 'Shuaib Ajouhaar', 'Manager', 'sajouhaar', '$2y$10$A8wxJjbQLmiN95byY3Z7DOym3wQ3a4ujULMqF7QcAWpg6P3d5KRQi', '2026-05-13 12:57:22'),
(2, 'Counter Staff 1', 'Cashier', 'cashier1', '$2y$10$mLPfmF8PVvpFcJCm9OWUpeVoYLzWH/QvjdyK1H0nQuy8hmxPK1pjC', '2026-05-13 12:57:22'),
(3, 'Counter Staff 2', 'Cashier', 'cashier2', '$2y$10$qv.g7a.Tb31lJjuKhmMKbOE7KwnjMdoS/loVDs811s1YwM3j0q4/2', '2026-05-13 12:57:22'),
(4, 'Counter Staff 3', 'Cashier', 'cashier3', '$2a$11$B.j0zrfX8U46VoPcJu3ysefkWo/TgCNlFK.a7ba0hv6K4LDntx8Bu', '2026-05-13 21:13:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `receipts`
--
ALTER TABLE `receipts`
  ADD PRIMARY KEY (`receipt_id`),
  ADD UNIQUE KEY `sale_id` (`sale_id`),
  ADD UNIQUE KEY `receipt_number` (`receipt_number`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sale_id`),
  ADD UNIQUE KEY `receipt_number` (`receipt_number`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `sale_items`
--
ALTER TABLE `sale_items`
  ADD PRIMARY KEY (`sale_item_id`),
  ADD KEY `sale_id` (`sale_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `receipts`
--
ALTER TABLE `receipts`
  MODIFY `receipt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sale_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=311;

--
-- AUTO_INCREMENT for table `sale_items`
--
ALTER TABLE `sale_items`
  MODIFY `sale_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `receipts`
--
ALTER TABLE `receipts`
  ADD CONSTRAINT `receipts_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`),
  ADD CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `sale_items`
--
ALTER TABLE `sale_items`
  ADD CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`),
  ADD CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
