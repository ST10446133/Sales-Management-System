# PHP/MySQL Database

This folder contains the PHP/MySQL database setup for the Ajouhaar Moslem Butchery Sales and Stock Management System.

## Database

Database name: `ajouhaar_butchery`

Tables:

- `users`
- `products`
- `customers`
- `sales`
- `sale_items`
- `receipts`

## Default Login Details

- Manager: `sajouhaar` / `1234`
- Cashier: `cashier1` / `1234`
- Cashier: `cashier2` / `1234`

Passwords are saved with PHP `password_hash`, not as plain text.

## How To Create The Database

1. Start Apache and MySQL in XAMPP.
2. Copy the `database` folder into your XAMPP `htdocs` folder, or open it from a PHP-enabled server.
3. Open this page in your browser:

   `http://localhost/database/setup_database.php`

Alternative:

1. Open phpMyAdmin.
2. Import `schema.sql`.
3. Run `setup_database.php` to insert the default users, products, stock and sample sales.

## ASP.NET Connection

The ASP.NET C# website now connects to this MySQL database through `Data/ButcheryDataStore.cs`.
